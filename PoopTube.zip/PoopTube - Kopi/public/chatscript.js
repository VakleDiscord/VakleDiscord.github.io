const plus = document.getElementById("plus");
const profile = document.getElementById("profile");
const rate1 = document.getElementById("rating1");
const rate2 = document.getElementById("rating2");
const rate3 = document.getElementById("rating3");
const rate4 = document.getElementById("rating4");
const rate5 = document.getElementById("rating5");
const progressbar = document.getElementById("pro-bar");
const progressEle = document.getElementById("loading-progress");
const levelEle = document.getElementById("level");
const levelCount = document.getElementById("levelcount");
const msg = document.getElementById("messages");


var objlogins = [
    {
        username: "Vakle",
        password: "Val#2022"
    },
    {
        username: "Vakle2",
        password: "ADMIN"
    },
    {
        username: "Vakle3",
        password: "ADMIN"
    }
]
function getcookiedata() {
    var user = getCookie('myusername');
    var pass = getCookie('mypassword');

    document.getElementById("username").value =user;
    document.getElementById("password").value =pass;

}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function chatting(event) {
    window.location.href = "?chat=" + event.target.innerHTML +"&userid=" + getCookie("myusername")
}

function getParameter(paraName) {
    let parameters = new URLSearchParams(window.location.search );
    return parameters.get(paraName);
}

function checkpara() {
    //look for chats in
    if (getParameter("chat") != null) {
        if(getParameter("userid") != null) {
            U_sender = getParameter("userid") //The user who is using the interface
            U_rec = getParameter("chat") //The other user
            if(U_sender != getCookie("myusername")) {
                window.location.replace("chat.html");
            }else {
                messageCheck(U_sender, U_rec);
                document.getElementById("users").remove();
                document.getElementById("msg").style.visibility = "visible"
            }
        }
    }
}

function messageCheck(user1, user2) {
    msg.innerHTML = "";

    if(user1!= getCookie("myusername")) {
        window.location.replace("chat.html");
    } else {
        fetch('./src/messages.json')
        .then(res => res.json())
        .then(data => {
            for (var i = 0; i < data.length; i++) {
                if(user1 == data[i].user1 && user2 == data[i].user2 || user2 == data[i].user1 && user1 == data[i].user2){
                    if(user1 == data[i].user1 ) {
                        const template = document.createElement("div");
                        template.setAttribute("id", "messageblob");
                        template.setAttribute("class", "msg1")
                        
                        template.innerHTML =`${data[i].message}`
                        msg.appendChild(template);
                        
                    }else{
                        const template = document.createElement("div");
                        template.setAttribute("id", "messageblob");
                        template.setAttribute("class", "msg2")
                        
                        template.innerHTML =`${data[i].message}`
                        msg.appendChild(template);
                    }
                }                
            }
        })
    }
    
}