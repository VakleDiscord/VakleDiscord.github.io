const plus = document.getElementById("plus");
const profile = document.getElementById("profile");
const rate1 = document.getElementById("rating1");
const rate2 = document.getElementById("rating2");
const rate3 = document.getElementById("rating3");
const rate4 = document.getElementById("rating4");
const rate5 = document.getElementById("rating5");
const progressbar = document.getElementById("pro-bar");
const progressEle = document.getElementById("loading-progress");
const levelEle = document.getElementById("level");
const levelCount = document.getElementById("levelcount");



var objlogins = [
    {
        username: "Vakle",
        password: "Val#2022"
    },
    {
        username: "Vakle2",
        password: "ADMIN"
    },
    {
        username: "Vakle3",
        password: "ADMIN"
    }
]



profile.appendChild(plus);
progressbar.appendChild(progressEle);
progressbar.appendChild(levelEle)

var outOf5 = 5;
score.innerHTML = String(outOf5 / 2) + "/5";
if (outOf5 != 0) {
    if (outOf5 > 1) {
        if (outOf5 > 2) {
            if (outOf5 > 3) {
                if (outOf5 > 4) {
                    if (outOf5 > 5) {
                        if (outOf5 > 6) {
                            if (outOf5 > 7) {
                                if (outOf5 > 8) {
                                    if (outOf5 > 9) {
                                        rate5.src="Rating shit.png";
                                    } else {
                                        rate5.src="Rating shit_half.png";
                                    }
                                }
                                rate4.src="Rating shit.png";
                            }else {
                                rate4.src="Rating shit_half.png";
                            }
                        }
                        rate3.src="Rating shit.png";
                    }else{
                        rate3.src="Rating shit_half.png";
                    }
                }
                rate2.src="Rating shit.png";
            }else{
                rate2.src="Rating shit_half.png";
            }
        }
        rate1.src="Rating shit.png";
    }else{
        rate1.src="Rating shit_half.png";
    }
}

var level = 38;
levelCount.innerHTML = String(level);

/* PROGRESSBAR */

var progress = 69;
progressEle.style.width = String(progress / 100  * 24) + "vh";

progressEle.style.left = String(progress / 100 - 1 * (12 + -0.11*progress)) + "vh";

/* LOG IN */

function logIn() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    const remember = document.getElementById("remember").value;

    for (i = 0; i < objlogins.length; i++) {
        if(username == objlogins[i].username && password == objlogins[i].password) {
            document.cookie="myusername=" +username+";path=http://localhost/web6pm"
            if (remember == "on") {
                
                document.cookie="mypassword=" +password+";path=http://localhost/web6pm"
            }
            document.getElementById("loginEle").remove();
            
        }
    }
}

function getcookiedata() {
    var user = getCookie('myusername');
    var pass = getCookie('mypassword');

    document.getElementById("username").value =user;
    document.getElementById("password").value =pass;

}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function chatting(event) {
    window.location.href = "?chat=" + event.target.innerHTML +"&userid=" + getCookie("myusername")
}

function getParameter(paraName) {
    let parameters = new URLSearchParams(window.location.search );
    return parameters.get(paraName);
}

function checkpara() {
    //look for chats in
    if (getParameter("chat") != null) {
        if(getParameter("userid") != null) {
            U_sender = getParameter("userid") //The user who is using the interface
            U_rec = getParameter("chat") //The other user
            if(U_sender != getCookie("myusername")) {
                window.location.replace("chat.html");
            }else {
                messageCheck();
            }
        }
    }
}

